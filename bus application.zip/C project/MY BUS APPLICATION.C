#include <stdio.h>

int main() {
    int bus, qty, prize,back, total = 0;

    printf("\t\t\t\t\t\tBUS TRAVEL\t\t\t\t\t\t\n");
    printf("\t\t\t\t\t\t----------\t\t\t\t\t\t\n\n");
    MAIN:
    printf("_____________---TRAVEL BUSES---_________________---BUS TYPE---______________---PLACES---____________\n\n");
    printf("1.CHOLA PARADAISE(CHENNAI TO TRICHY)\t->\tAC AND NON AC\t->\tARIYALUR,PERAMBALUR,TRICHY\n\n");
    printf("2.SPEEDER SERAN(CHENNAI TO KERALA)\t->\tAC AND NON AC\t->\tKOZHIKODU,THIRUVANANTHAPURAM,WEST HILLS\n\n");
    printf("3.PANDIAN PANTHERS(CHENNAI TO MADURAI)\t->\tAC AND NON AC\t->\tMADURAI,AVANIYAPURAM,THIRUPARANKUNDRAM\n\n");
    printf("__________________________________________________________________________________________________________\n\n");
    printf("\t\t\t\t\tSELECT YOUR FAVORITE TRAVEL BUS\t\t\t\t\n");
    printf("\t\t\t\t\t________________________________\t\t\t\t\n\n");
    printf("\t\t\t\t\t\n 1.CHOLA PARADAISE(CHEN TO TRICHY)\n 2.SPEEDER SERAN(CHEN TO KERALA) \n 3.PANDIAN PANTHERS(CHEN TO MADURAI) \t=~> \t ");
    scanf("%d", &bus);

    switch (bus) {
    case 1: {
        int ac, sleeper, to;
        BUS:
        printf("\n\t\t\t\tTHANK YOU FOR SELECTING CHOLA PARADAISE\t\t\t\t\t\t\n");
        printf("\t\t\t\t*****************************************\t\t\t\t\n\n");
        printf("\n\t\t\t\t\tSELECT YOUR BUS TYPE\t\t\n");
        printf("\t\t\t\t\t____________________\t\t\n\n");
        printf("\t\t 1.AC \n \t\t 2.NON AC\t\t");
        scanf("%d", &ac);

        switch (ac) {
        case 1: {
            printf("\n\t\t\tSELECT YOUR COMFORTABLE TRAVEL MODE\t\t\t\n");
            printf("\t\t\t_____________________________________\t\t\t\t\n\n");
            printf("\t\t 1.SLEEPER SEAT \n\t\t 2.NORMAL SEAT\t\t");
            scanf("%d", &sleeper);

            switch (sleeper) {
            case 1: {
                printf("\n\t\t\t YOUR SELECTED IT SLEEPER MODE SEAT\t\t\n");
                printf("\t\t\t....................................\t\t\n\n");
                printf("\t\t\t\tWHERE ARE YOU GOING NOW\n");
                printf("\t\t\t\t^______________________^\t\t\t\t\n\n");
                printf("\t\t\t 1.ARIYALUR \n\t\t\t2.PERAMBALUR \n\t\t\t3.TRICHY\t\t");
                scanf("%d", &to);


                switch (to) {
                case 1: {
                    printf("\n\t\t\tYOUR SELECTED PLACE IS ARIYALUR\t\t\t\t\n");
                    printf("\t\t\t________________________________\t\t\t\t\n\n");
                    printf("\n\t\t\t\t\tHOW MANY TICKETS WANT YOU\t=~>\t");
                    scanf("%d", &qty);
                    prize = 500 * qty;
                    total += prize;
                    printf("\n\t\t\t TOTAL AMOUNT IS =~> \t $ %d\t\t\n", total);
                    printf("\t\t 1.PAY THE AMOUNT\n\t\t 0.BACKPAGE&CONTINUE \n\t\t 3.GOTO MAIN MENU\t\t=\t");
                    scanf("%d",&back);
                    while(back==3)
                    goto MAIN;
                    if(back==0)
                    goto BUS;
                    if(back==1)
                    {printf("\t\t\t_____________________________________\t\t\n");
                    printf("\t\t\tTHANK YOU FOR BOOKING CHOLA PARADAISE\n\n\t\t\t\tENJOY YOUR JOURNEY\n");
                    printf("\t\t\t_____________________________________\t\t\n");}
                    else
                    {
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    printf("\n\n\t\t\t\t!!!!!!!!~YOUR ENTERED INVAILD OPTION PLEASE CHECK IT~!!!!!!!!\t\t\t\t\n");
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    }
                    break;
                }
                case 2: {
                    printf("\n\t\t\tYOUR SELECTED PLACE IS PERAMBALUR\t\t\t\n");
                    printf("\t\t\t___________________________________\t\t\t\t\n\n");
                    printf("\n\t\t\t\t\tHOW MANY TICKETS WANT YOU\t=~>\t");
                    scanf("%d", &qty);
                    prize = 450 * qty;
                    total += prize;
                    printf("\n\t\t\t TOTAL AMOUNT IS =~> \t $ %d\t\t\n", total);
                    printf("\t\t 1.PAY THE AMOUNT\n\t\t 0.BACKPAGECONTINUE \n\t\t 3.GOTO MAIN MENU\t=");
                    scanf("%d",&back);
                    while(back==3)
                    goto MAIN;
                    if(back==0)
                    goto BUS;
                    if(back==1)
                    {printf("\t\t\t_____________________________________\t\t\n");
                    printf("\t\t\tTHANK YOU FOR BOOKING CHOLA PARADAISE \n\n\t\t\t\tENJOY YOUR JOURNEY\t\t\n");
                    printf("\t\t\t_____________________________________\t\t\n");}
                    else
                    {
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    printf("\n\n\t\t\t\t!!!!!!!!~YOUR ENTERED INVAILD OPTION PLEASE CHECK IT~!!!!!!!!\t\t\t\t\n");
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    }
                    break;
                }
                case 3: {
                    printf("\n\t\t\tYOUR SELECTED PLACE IS TRICHY\t\t\t\n");
                    printf("\t\t\t________________________________\t\t\t\t\n\n");
                    printf("\n\t\t\t\t\tHOW MANY TICKETS WANT YOU\t=~>\t");
                    scanf("%d", &qty);
                    prize = 1000 * qty;
                    total += prize;
                    printf("\n\t\t\t TOTAL AMOUNT IS =~> \t $ %d\t\t\n", total);
                    printf("\t\t 1.PAY THE AMOUNT\n\t\t 0.BACKPAGE&CONTINUE \n\t\t 3.GOTO MAIN MENU\t=");
                    scanf("%d",&back);
                    while(back==3)
                    goto MAIN;
                    if(back==0)
                    goto BUS;
                    if(back==1)
                    {printf("\t\t\t_____________________________________\t\t\n");
                    printf("\t\t\tTHANK YOU FOR BOOKING CHOLA PARADAISE\n\n\t\t\t\tENJOY YOUR JOURNEY\t\t\n");
                    printf("\t\t\t_____________________________________\t\t\n");}
                    else
                    {
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    printf("\n\n\t\t\t\t!!!!!!!!~YOUR ENTERED INVAILD OPTION PLEASE CHECK IT~!!!!!!!!\t\t\t\t\n");
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    }
                    break;
                }
                }
                break;
            }
            case 2: {
                int no;
                printf("\t\t\tYOUR SELECTED NORMAL MODE SEAT\t\t\n");
                printf("\t\t\t_____________________________________\t\t\t\t\n\n");
                printf("\t\t\tWHERE ARE YOU GOING\t\t\n");
                printf("\t\t 1.ARIYALUR\n \t\t2.PERAMBALUR\n\t\t 3.TRICHY\t\t\n\n ");
                scanf("%d", &no);

                switch (no) {
                case 1: {
                    printf("\n\t\t\tYOUR SELECTED ARIYALUR\t\t\n");
                    printf("\t\t\t________________________________\t\t\t\t\n\n");
                    printf("\n\t\t\t\t\tHOW MANY TICKETS WANT YOU\t=~>\t");
                    scanf("%d", &qty);
                    prize = 210 * qty;
                    total += prize;
                    printf("\n\t\t\t TOTAL AMOUNT IS =~> \t $ %d\t\t\n", total);
                    printf("\t\t 1.PAY THE AMOUNT\n\t\t 0.BACKPAGE&CONTINUE \n\t\t 3.GOTO MAIN MENU\t=");
                    scanf("%d",&back);
                    while(back==3)
                    goto MAIN;
                    if(back==0)
                    goto BUS;
                    if(back==1)
                    {printf("\t\t\t_____________________________________\t\t\n");
                    printf("\t\t\tTHANK YOU FOR BOOKING CHOLA PARADAISE\n\n\t\t\t\tENJOY YOUR JOURNEY\t\t\n");
                    printf("\t\t\t_____________________________________\t\t\n");}
                    else
                    {
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    printf("\n\n\t\t\t\t!!!!!!!!~YOUR ENTERED INVAILD OPTION PLEASE CHECK IT~!!!!!!!!\t\t\t\t\n");
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    }
                    break;
                }
                case 2: {
                    printf("\n\t\t\tYOUR SELECTED PERAMBALUR\t\t\t");
                    printf("\t\t\t________________________________\t\t\t\t\n\n");
                    printf("\n\t\t\t\t\tHOW MANY TICKETS WANT YOU\t=~>\t");
                    scanf("%d", &qty);
                    prize = 245 * qty;
                    total += prize;
                    printf("\n\t\t\t TOTAL AMOUNT IS =~> \t $ %d\t\t\n", total);
                    printf("\t\t 1.PAY THE AMOUNT\n\t\t 0.BACKPAGE&CONTINUE \n\t\t 3.GOTO MAIN MENU\t=");
                    scanf("%d",&back);
                    while(back==3)
                    goto MAIN;
                    if(back==0)
                    goto BUS;
                    if(back==1)
                    {printf("\t\t\t_____________________________________\t\t\n");
                    printf("\t\t\tTHANK YOU FOR BOOKING CHOLA PARADAISE\n\n\t\t\t\tENJOY YOUR JOURNEY\t\t\n");
                    printf("\t\t\t_____________________________________\t\t\n");}
                    else
                    {
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    printf("\n\n\t\t\t\t!!!!!!!!~YOUR ENTERED INVAILD OPTION PLEASE CHECK IT~!!!!!!!!\t\t\t\t\n");
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    }
                    break;
                }
                case 3: {
                    printf("\n\t\t\tYOUR SELECTED TRICHY\t\t\t\n");
                    printf("\t\t\t________________________________\t\t\t\t\n\n");
                    printf("\n\t\t\t\t\tHOW MANY TICKETS WANT YOU\t=~>\t");
                    scanf("%d", &qty);
                    prize = 400 * qty;
                    total += prize;
                    printf("\n\t\t\t TOTAL AMOUNT IS =~> \t $ %d\t\t\n", total);
                    printf("\t\t 1.PAY THE AMOUNT\n\t\t 0.BACKPAGE&CONTINUE \n\t\t 3.GOTO MAIN MENU\t=");
                    scanf("%d",&back);
                    while(back==3)
                    goto MAIN;
                    if(back==0)
                    goto BUS;
                    if(back==1)
                    {printf("\t\t\t_____________________________________\t\t\n");
                    printf("\t\t\tTHANK YOU FOR BOOKING CHOLA PARADAISE\n\n\t\t\t\tENJOY YOUR JOURNEY\t\t\n");
                    printf("\t\t\t_____________________________________\t\t\n");}
                    else
                    {
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    printf("\n\n\t\t\t\t!!!!!!!!~YOUR ENTERED INVAILD OPTION PLEASE CHECK IT~!!!!!!!!\t\t\t\t\n");
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    }
                    break;
                }
                }
                break;
            }
            }
            break;
        }
        case 2: {
            int nonac;

            printf("\t\t\tYOUR SELECTED NON-AC BUS\t\t\n");
            printf("\t\t\t________________________________\t\t\t\t\n\n");
            printf("\t\t\tSELECT YOUR BUS TYPE\t\t\n\n");
            printf("\t\t\t 1.NORMAL BUS\n\t\t\t 2.EXPRESS BUS\t\t");
            scanf("%d", &nonac);

            switch (nonac) {
            case 1: {
                int fm;
                printf("\n\t\t\tYOUR SELECTED NORMAL TYPE BUS\t\t\n");
                printf("\t\t\t________________________________\t\t\t\t\n\n");
                printf("\t\t\tWHERE ARE YOU GOING TO\t\t\n\n");
                printf("\t\t\t1.ARIYALUR\n\t\t\t2.PERAMBALUR\n\t\t\t3.TRICHY\t\t");
                scanf("%d", &fm);

                switch (fm) {
                case 1: {
                    printf("\n\t\t\tYOUR SELECTED ARIYALUR\t\t\n");
                    printf("\t\t\t________________________________\t\t\t\t\n\n");
                    printf("\n\t\t\t\t\tHOW MANY TICKETS WANT YOU\t=~>\t");
                    scanf("%d", &qty);
                    prize = 120*qty;
                    total += prize;
                    printf("\n\t\t\t TOTAL AMOUNT IS =~> \t $ %d\t\t\n", total);
                    printf("\t\t 1.PAY THE AMOUNT\n\t\t 0.BACKPAGE&CONTINUE \n\t\t 3.GOTO MAIN MENU\t=");
                    scanf("%d",&back);
                    while(back==3)
                    goto MAIN;
                    if(back==0)
                    goto BUS;
                    if(back==1)
                    {printf("\t\t\t_____________________________________\t\t\n");
                    printf("\t\t\tTHANK YOU FOR BOOKING CHOLA PARADAISE\n\n\t\t\t\tENJOY YOUR JOURNEY\t\t\n");
                    printf("\t\t\t_____________________________________\t\t\n");}
                    else
                    {
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    printf("\n\n\t\t\t\t!!!!!!!!~YOUR ENTERED INVAILD OPTION PLEASE CHECK IT~!!!!!!!!\t\t\t\t\n");
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    }
                    break;
                }
                case 2: {
                    printf("\n\t\t\tYOUR SELECTED PERAMBALUR\t\t\n");
                    printf("\t\t\t________________________________\t\t\t\t\n\n");
                    printf("\n\t\t\t\t\tHOW MANY TICKETS WANT YOU\t=~>\t");
                    scanf("%d", &qty);
                    prize = 140 * qty;
                    total += prize;
                    printf("\n\t\t\t TOTAL AMOUNT IS =~> \t $ %d\t\t\n", total);
                    printf("\t\t 1.PAY THE AMOUNT\n\t\t 0.BACKPAGE&CONTINUE \n\t\t 3.GOTO MAIN MENU\t=");
                    scanf("%d",&back);
                    while(back==3)
                    goto MAIN;
                    if(back==0)
                    goto BUS;
                    if(back==1)
                    {printf("\t\t\t_____________________________________\t\t\n");
                    printf("\t\t\tTHANK YOU FOR BOOKING CHOLA PARADAISE\n\n\t\t\t\tENJOY YOUR JOURNEY\t\t\n");
                    printf("\t\t\t_____________________________________\t\t\n");}
                    else
                    {
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    printf("\n\n\t\t\t\t!!!!!!!!~YOUR ENTERED INVAILD OPTION PLEASE CHECK IT~!!!!!!!!\t\t\t\t\n");
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    }
                    break;
                }
                case 3: {
                    printf("\n\t\t\tYOUR SELECTED TRICHY\t\t\n");
                    printf("\t\t\t________________________________\t\t\t\t\n\n");
                    printf("\n\t\t\t\t\tHOW MANY TICKETS WANT YOU\t=~>\t");
                    scanf("%d", &qty);
                    prize = 220 * qty;
                    total += prize;
                    printf("\n\t\t\t TOTAL AMOUNT IS =~> \t $ %d\t\t\n", total);
                    printf("\t\t 1.PAY THE AMOUNT\n\t\t 0.BACKPAGE&CONTINUE \n\t\t 3.GOTO MAIN MENU\t=");
                    scanf("%d",&back);
                    while(back==3)
                    goto MAIN;
                    if(back==0)
                    goto BUS;
                    if(back==1)
                    {printf("\t\t\t_____________________________________\t\t\n");
                    printf("\t\t\tTHANK YOU FOR BOOKING CHOLA PARADAISE\n\n\t\t\t\tENJOY YOUR JOURNEY\t\t\n");
                    printf("\t\t\t_____________________________________\t\t\n");}
                    else
                    {
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    printf("\n\n\t\t\t\t!!!!!!!!~YOUR ENTERED INVAILD OPTION PLEASE CHECK IT~!!!!!!!!\t\t\t\t\n");
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    }
                    break;
                }
                }
                break;
            }
            case 2: {
                int k;
                printf("\n\t\t\tYOUR SELECTED EXPRESS BUS\t\t\n");
                printf("\t\t\t________________________________\t\t\t\t\n\n");
                printf("\t\t\tWHERE ARE YOU GOING TO\t\t\n\n");
                printf("\t\t 1.ARIYALUR \n\t\t 2.PERAMBALUR\n\t\t 3.TRICHY");
                scanf("%d", &k);

                switch (k) {
                case 1: {
                    printf("\n\t\t\tYOUR SELECTED ARIYALUR\t\t\n");
                    printf("\t\t\t________________________________\t\t\t\t\n\n");
                    printf("\n\t\t\t\t\tHOW MANY TICKETS WANT YOU\t=~>\t");
                    scanf("%d", &qty);
                    prize = 120*qty;
                    total += prize;
                    printf("\n\t\t\t TOTAL AMOUNT IS =~> \t $ %d\t\t\n", total);
                    printf("\t\t 1.PAY THE AMOUNT\n\t\t 0.BACKPAGE&CONTINUE \n\t\t 3.GOTO MAIN MENU\t=");
                    scanf("%d",&back);
                    while(back==3)
                    goto MAIN;
                    if(back==0)
                    goto BUS;
                    if(back==1)
                    {printf("\t\t\t_____________________________________\t\t\n");
                    printf("\t\t\tTHANK YOU FOR BOOKING CHOLA PARADAISE\n\n\t\t\t\tENJOY YOUR JOURNEY\t\t\n");
                    printf("\t\t\t_____________________________________\t\t\n");}
                    else
                    {
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    printf("\n\n\t\t\t\t!!!!!!!!~YOUR ENTERED INVAILD OPTION PLEASE CHECK IT~!!!!!!!!\t\t\t\t\n");
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    }
                    break;
                }
                case 2: {
                    printf("\n\t\t\tOUR SELECTED PERAMBALUR\t\t\n");
                    printf("\t\t\t________________________________\t\t\t\t\n\n");
                    printf("\n\t\t\t\t\tHOW MANY TICKETS WANT YOU\t=~>\t");
                    scanf("%d", &qty);
                    prize = 190 * qty;
                    total += prize;
                    printf("\n\t\t\t TOTAL AMOUNT IS =~> \t $ %d\t\t\n", total);
                    printf("\t\t1.PAY THE AMOUNT\n\t\t 0.BACKPAGE&CONTINUE \n\t\t 3.GOTO MAIN MENU\t=");
                    scanf("%d",&back);
                    while(back==3)
                    goto MAIN;
                    if(back==0)
                    goto BUS;
                    if(back==1)
                    {printf("\t\t\t_____________________________________\t\t\n");
                    printf("\t\t\tTHANK YOU FOR BOOKING CHOLA PARADAISE\n\n\t\t\t\tENJOY YOUR JOURNEY\t\t\n");
                    printf("\t\t\t_____________________________________\t\t\n");}
                    else
                    {
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    printf("\n\n\t\t\t\t!!!!!!!!~YOUR ENTERED INVAILD OPTION PLEASE CHECK IT~!!!!!!!!\t\t\t\t\n");
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    }
                    break;
                }
                case 3: {
                    printf("\n\t\t\tYOUR SELECTED TRICHY\t\t\n");
                    printf("\t\t\t________________________________\t\t\t\t\n\n");
                    printf("\n\t\t\t\t\tHOW MANY TICKETS WANT YOU\t=~>\t");
                    scanf("%d", &qty);
                    prize = 350 * qty;
                    total += prize;
                    printf("\n\t\t\t TOTAL AMOUNT IS =~> \t $ %d\t\t\n", total);
                    printf("\t\t 1.PAY THE AMOUNT\n\t\t 0.BACKPAGE&CONTINUE \n\t\t 3.GOTO MAIN MENU\t=");
                    scanf("%d",&back);
                    while(back==3)
                    goto MAIN;
                    if(back==0)
                    goto BUS;
                    if(back==1)
                    {printf("\t\t\t_____________________________________\t\t\n");
                    printf("\t\t\tTHANK YOU FOR BOOKING CHOLA PARADAISE\n\n\t\t\t\tENJOY YOUR JOURNEY\t\t\n");
                    printf("\t\t\t_____________________________________\t\t\n");}
                    else
                    {
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    printf("\n\n\t\t\t\t!!!!!!!!~YOUR ENTERED INVAILD OPTION PLEASE CHECK IT~!!!!!!!!\t\t\t\t\n");
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    }
                    break;
                }
                }

            }
            }

        }
        }
break;
    }    case 2:
        {
        int ac, sleeper, to;
        GO:
        printf("\n\t\t\t\tTHANK YOU FOR SELECTING SPEEDER SERAN \t\t\t\t\t\t\n");
        printf("\t\t\t\t*****************************************\t\t\t\t\n\n");
        printf("\n\t\t\t\t\tSELECT YOUR BUS TYPE\t\t\n");
        printf("\t\t\t\t\t____________________\t\t\n\n");
        printf("\t\t 1.AC \n \t\t 2.NON AC\t\t");
        scanf("%d", &ac);

        switch (ac) {
        case 1: {
            printf("\n\t\t\tSELECT YOUR COMFORTABLE TRAVEL MODE\t\t\t\n");
            printf("\t\t\t_____________________________________\t\t\t\t\n\n");
            printf("\t\t 1.SLEEPER SEAT \n\t\t 2.NORMAL SEAT\t\t");
            scanf("%d", &sleeper);

            switch (sleeper) {
            case 1: {
                printf("\n\t\t\t YOUR SELECTED IT'S SLEEPER MODE SEAT\t\t\n");
                printf("\t\t\t....................................\t\t\n\n");
                printf("\t\t\t\tWHERE ARE YOU GOING NOW\n");
                printf("\t\t\t\t^______________________^\t\t\t\t\n\n");
                printf("\t\t\t 1.KOZHIKODU \n\t\t\t2.THIRUVANANTHAPURAM \n\t\t\t3.WEST HILLS\t\t");
                scanf("%d", &to);

                switch (to) {
                case 1: {
                    printf("\n\t\t\tYOUR SELECTED PLACE IS KOZHIKODU\t\t\t\t\n");
                    printf("\t\t\t________________________________\t\t\t\t\n\n");
                    printf("\n\t\t\t\t\tHOW MANY TICKETS WANT YOU\t=~>\t");
                    scanf("%d", &qty);
                    prize = 1000 * qty;
                    total += prize;
                    printf("\n\t\t\t TOTAL AMOUNT IS =~> \t $ %d\t\t\n", total);
                    printf("\t\t 1.PAY THE AMOUNT\n\t\t 0.BACKPAGE&CONTINUE \n\t\t 3.GOTO MAIN MENU\t=");
                    scanf("%d",&back);
                    while(back==3)
                    goto MAIN;
                    if(back==0)
                    goto GO;
                    if(back==1)
                    {printf("\t\t\t_____________________________________\t\t\n");
                    printf("\t\t\tTHANK YOU FOR BOOKING SPEEDER SERAN\n\n\t\t\t\tENJOY YOUR JOURNEY\t\t\n");
                    printf("\t\t\t_____________________________________\t\t\n");}
                    else
                    {
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    printf("\n\n\t\t\t\t!!!!!!!!~YOUR ENTERED INVAILD OPTION PLEASE CHECK IT~!!!!!!!!\t\t\t\t\n");
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    }
                    break;
                }
                case 2: {
                    printf("\n\t\t\tYOUR SELECTED PLACE IS THIRUVANANTHAPURAM\t\t\t\n");
                    printf("\t\t\t___________________________________\t\t\t\t\n\n");
                    printf("\n\t\t\t\t\tHOW MANY TICKETS WANT YOU\t=~>\t");
                    scanf("%d", &qty);
                    prize = 850 * qty;
                    total += prize;
                    printf("\n\t\t\t TOTAL AMOUNT IS =~> \t $ %d\t\t\n", total);
                    printf("\t\t 1.PAY THE AMOUNT\n\t\t 0.BACKPAGE&CONTINUE \n\t\t 3.GOTO MAIN MENU\t=");
                    scanf("%d",&back);
                    while(back==3)
                    goto MAIN;
                    if(back==0)
                    goto GO;
                    if(back==1)
                    {printf("\t\t\t_____________________________________\t\t\n");
                    printf("\t\t\tTHANK YOU FOR BOOKING SPEEDER SERAN\n\n\t\t\t\tENJOY YOUR JOURNEY\t\t\n");
                    printf("\t\t\t_____________________________________\t\t\n");}
                    else
                    {
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    printf("\n\n\t\t\t\t!!!!!!!!~YOUR ENTERED INVAILD OPTION PLEASE CHECK IT~!!!!!!!!\t\t\t\t\n");
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    }
                    break;
                }
                case 3: {
                    printf("\n\t\t\tYOUR SELECTED PLACE IS WEST HILLS\t\t\t\n");
                    printf("\t\t\t________________________________\t\t\t\t\n\n");
                    printf("\n\t\t\t\t\tHOW MANY TICKETS WANT YOU\t=~>\t");
                    scanf("%d", &qty);
                    prize = 750 * qty;
                    total += prize;
                    printf("\n\t\t\t TOTAL AMOUNT IS =~> \t $ %d\t\t\n", total);
                    printf("\t\t 1.PAY THE AMOUNT\n\t\t 0.BACKPAGE&CONTINUE \n\t\t 3.GOTO MAIN MENU\t=");
                    scanf("%d",&back);
                    while(back==3)
                    goto MAIN;
                    if(back==0)
                    goto GO;
                    if(back==1)
                    {printf("\t\t\t_____________________________________\t\t\n");
                    printf("\t\t\tTHANK YOU FOR BOOKING SPEEDER SERAN\n\n\t\t\t\tENJOY YOUR JOURNEY\t\t\n");
                    printf("\t\t\t_____________________________________\t\t\n");}
                    else
                    {
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    printf("\n\n\t\t\t\t!!!!!!!!~YOUR ENTERED INVAILD OPTION PLEASE CHECK IT~!!!!!!!!\t\t\t\t\n");
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    }
                    break;
                }
                }
                break;
            }
            case 2: {
                int no;
                printf("\n\t\t\tYOUR SELECTED NORMAL MODE SEAT\t\t\n");
                printf("\t\t\t_____________________________________\t\t\t\t\n\n");
                printf("\t\t\tWHERE ARE YOU GOING\t\t\n");
                printf("\t\t 1.KOZHIKODU\n \t\t2.THIRUVANANTHAPURAM\n\t\t 3.WEST HILLS\t\t\n\n ");
                scanf("%d", &no);

                switch (no) {
                case 1: {
                    printf("\n\t\t\tYOUR SELECTED KOZHIKODU\t\t\n");
                    printf("\t\t\t________________________________\t\t\t\t\n\n");
                    printf("\n\t\t\t\t\tHOW MANY TICKETS WANT YOU\t=~>\t");
                    scanf("%d", &qty);
                    prize = 800 * qty;
                    total += prize;
                    printf("\n\t\t\t TOTAL AMOUNT IS =~> \t $ %d\t\t\n", total);
                    printf("\t\t 1.PAY THE AMOUNT\n\t\t 0.BACKPAGE&CONTINUE \n\t\t 3.GOTO MAIN MENU\t=");
                    scanf("%d",&back);
                    while(back==3)
                    goto MAIN;
                    if(back==0)
                    goto GO;
                    if(back==1)
                    {printf("\t\t\t_____________________________________\t\t\n");
                    printf("\t\t\tTHANK YOU FOR BOOKING SPEEDER SERAN\n\n\t\t\t\tENJOY YOUR JOURNEY\t\t\n");
                    printf("\t\t\t_____________________________________\t\t\n");}
                    else
                    {
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    printf("\n\n\t\t\t\t!!!!!!!!~YOUR ENTERED INVAILD OPTION PLEASE CHECK IT~!!!!!!!!\t\t\t\t\n");
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    }
                    break;
                }
                case 2: {
                    printf("\n\t\t\tYOUR SELECTED THIRUVANANTHAPURAM\t\t\t");
                    printf("\t\t\t________________________________\t\t\t\t\n\n");
                    printf("\n\t\t\t\t\tHOW MANY TICKETS WANT YOU\t=~>\t");
                    scanf("%d", &qty);
                    prize = 620 * qty;
                    total += prize;
                    printf("\n\t\t\t TOTAL AMOUNT IS =~> \t $ %d\t\t\n", total);
                    printf("\t\t 1.PAY THE AMOUNT\n\t\t 0.BACKPAGE&CONTINUE \n\t\t 3.GOTO MAIN MENU\t=");
                    scanf("%d",&back);
                    while(back==3)
                    goto MAIN;
                    if(back==0)
                    goto GO;
                    if(back==1)
                    {printf("\t\t\t_____________________________________\t\t\n");
                    printf("\t\t\tTHANK YOU FOR BOOKING SPEEDER SERAN\n\n\t\t\t\tENJOY YOUR JOURNEY\t\t\n");
                    printf("\t\t\t_____________________________________\t\t\n");}
                    else
                    {
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    printf("\n\n\t\t\t\t!!!!!!!!~YOUR ENTERED INVAILD OPTION PLEASE CHECK IT~!!!!!!!!\t\t\t\t\n");
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    }
                    break;
                }
                case 3: {
                    printf("\n\t\t\tYOUR SELECTED WEST HILLS\t\t\t\n");
                    printf("\t\t\t________________________________\t\t\t\t\n\n");
                    printf("\n\t\t\t\t\tHOW MANY TICKETS WANT YOU\t=~>\t");
                    scanf("%d", &qty);
                    prize = 550 * qty;
                    total += prize;
                    printf("\n\t\t\t TOTAL AMOUNT IS =~> \t $ %d\t\t\n", total);
                    printf("\t\t 1.PAY THE AMOUNT\n\t\t 0.BACKPAGE&CONTINUE \n\t\t 3.GOTO MAIN MENU\t=");
                    scanf("%d",&back);
                    while(back==3)
                    goto MAIN;
                    if(back==0)
                    goto GO;
                     if(back==1)
                    {printf("\t\t\t_____________________________________\t\t\n");
                    printf("\t\t\tTHANK YOU FOR BOOKING SPEEDER SERAN\n\n\t\t\t\tENJOY YOUR JOURNEY\t\t\n");
                    printf("\t\t\t_____________________________________\t\t\n");}
                    else
                    {
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    printf("\n\n\t\t\t\t!!!!!!!!~YOUR ENTERED INVAILD OPTION PLEASE CHECK IT~!!!!!!!!\t\t\t\t\n");
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    }
                    break;
                }
                }
                break;
            }
            }
            break;
        }
        case 2: {
            int nonac;

            printf("\n\t\t\tYOUR SELECTED NON-AC BUS\t\t\n");
            printf("\t\t\t________________________________\t\t\t\t\n\n");
            printf("\t\t\tSELECT YOUR BUS TYPE\t\t\n\n");
            printf("\t\t\t 1.NORMAL BUS\n\t\t\t 2.EXPRESS BUS\t\t");
            scanf("%d", &nonac);

            switch (nonac) {
            case 1: {
                int fm;
                printf("\n\t\t\tYOUR SELECTED NORMAL TYPE BUS\t\t\n");
                printf("\t\t\t________________________________\t\t\t\t\n\n");
                printf("\t\t\tWHERE ARE YOU GOING TO\t\t\n\n");
                printf("\t\t\t1.KOZHIKODU\n\t\t\t2.THIRUVANANTHAPURAM\n\t\t\t3.WEST HILLS\t\t");
                scanf("%d", &fm);

                switch (fm) {
                case 1: {
                    printf("\n\t\t\tYOUR SELECTED KOZHIKODU\t\t\n");
                    printf("\t\t\t________________________________\t\t\t\t\n\n");
                    printf("\n\t\t\t\t\tHOW MANY TICKETS WANT YOU\t=~>\t");
                    scanf("%d", &qty);
                    prize = 710*qty;
                    total += prize;
                    printf("\n\t\t\t TOTAL AMOUNT IS =~> \t $ %d\t\t\n", total);
                    printf("\t\t 1.PAY THE AMOUNT\n\t\t 0.BACKPAGE&CONTINUE \n\t\t 3.GOTO MAIN MENU\t=");
                    scanf("%d",&back);
                    while(back==3)
                    goto MAIN;
                    if(back==0)
                    goto GO;
                    if(back==1)
                    {printf("\t\t\t_____________________________________\t\t\n");
                    printf("\t\t\tTHANK YOU FOR BOOKING SPEEDER SERAN\n\n\t\t\t\tENJOY YOUR JOURNEY\t\t\n");
                    printf("\t\t\t_____________________________________\t\t\n");}
                    else
                    {
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    printf("\n\n\t\t\t\t!!!!!!!!~YOUR ENTERED INVAILD OPTION PLEASE CHECK IT~!!!!!!!!\t\t\t\t\n");
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    }
                    break;
                }
                case 2: {
                    printf("\n\t\t\tYOUR SELECTED THIRUVANANTHAPURAM\t\t\n");
                    printf("\t\t\t________________________________\t\t\t\t\n\n");
                    printf("\n\t\t\t\t\tHOW MANY TICKETS WANT YOU\t=~>\t");
                    scanf("%d", &qty);
                    prize = 565 * qty;
                    total += prize;
                    printf("\n\t\t\t TOTAL AMOUNT IS =~> \t $ %d\t\t\n", total);
                    printf("\t\t 1.PAY THE AMOUNT\n\t\t 0.BACKPAGE&CONTINUE \n\t\t 3.GOTO MAIN MENU\t=");
                    scanf("%d",&back);
                    while(back==3)
                    goto MAIN;
                    if(back==0)
                    goto GO;
                    if(back==1)
                    {printf("\t\t\t_____________________________________\t\t\n");
                    printf("\t\t\tTHANK YOU FOR BOOKING SPEEDER SERAN\n\n\t\t\t\tENJOY YOUR JOURNEY\t\t\n");
                    printf("\t\t\t_____________________________________\t\t\n");}
                    else
                    {
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    printf("\n\n\t\t\t\t!!!!!!!!~YOUR ENTERED INVAILD OPTION PLEASE CHECK IT~!!!!!!!!\t\t\t\t\n");
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    }
                    break;
                }
                case 3: {
                    printf("\n\t\t\tYOUR SELECTED WEST HILLS\t\t\n");
                    printf("\t\t\t________________________________\t\t\t\t\n\n");
                    printf("\n\t\t\t\t\tHOW MANY TICKETS WANT YOU\t=~>\t");
                    scanf("%d", &qty);
                    prize = 490 * qty;
                    total += prize;
                    printf("\n\t\t\t TOTAL AMOUNT IS =~> \t $ %d\t\t\n", total);
                    printf("\t\t 1.PAY THE AMOUNT\n\t\t 0.BACKPAGE&CONTINUE \n\t\t 3.GOTO MAIN MENU\t=");
                    scanf("%d",&back);
                    while(back==3)
                    goto MAIN;
                    if(back==0)
                    goto GO;
                    if(back==1)
                    {printf("\t\t\t_____________________________________\t\t\n");
                    printf("\t\t\tTHANK YOU FOR BOOKING SPEEDER SERAN\n\n\t\t\t\tENJOY YOUR JOURNEY\t\t\n");
                    printf("\t\t\t_____________________________________\t\t\n");}
                    else
                    {
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    printf("\n\n\t\t\t\t!!!!!!!!~YOUR ENTERED INVAILD OPTION PLEASE CHECK IT~!!!!!!!!\t\t\t\t\n");
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    }
                    break;
                }
                }
                break;
            }
            case 2: {
                int k;
                printf("\n\t\t\tYOUR SELECTED EXPRESS BUS\t\t\n");
                printf("\t\t\t________________________________\t\t\t\t\n\n");
                printf("\t\t\tWHERE ARE YOU GOING TO\t\t\n\n");
                printf("\t\t 1.KOZHIKODU \n\t\t 2.THIRUVANANTHAPURAM\n\t\t 3.WEST HILLS");
                scanf("%d", &k);

                switch (k) {
                case 1: {
                    printf("\n\t\t\tYOUR SELECTED KOZHIKODU\t\t\n");
                    printf("\t\t\t________________________________\t\t\t\t\n\n");
                    printf("\n\t\t\t\t\tHOW MANY TICKETS WANT YOU\t=~>\t");
                    scanf("%d", &qty);
                    prize = 610*qty;
                    total += prize;
                    printf("\n\t\t\t TOTAL AMOUNT IS =~> \t $ %d\t\t\n", total);
                    printf("\t\t 1.PAY THE AMOUNT\n\t\t 0.BACKPAGE&CONTINUE \n\t\t 3.GOTO MAIN MENU\t=");
                    scanf("%d",&back);
                    while(back==3)
                    goto MAIN;
                    if(back==0)
                    goto GO;
                    if(back==1)
                    {printf("\t\t\t_____________________________________\t\t\n");
                    printf("\t\t\tTHANK YOU FOR BOOKING SPEEDER SERAN\n\n\t\t\t\tENJOY YOUR JOURNEY\t\t\n");
                    printf("\t\t\t_____________________________________\t\t\n");}
                    else
                    {
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    printf("\n\n\t\t\t\t!!!!!!!!~YOUR ENTERED INVAILD OPTION PLEASE CHECK IT~!!!!!!!!\t\t\t\t\n");
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    }
                    break;
                }
                case 2: {
                    printf("\n\t\t\tYOUR SELECTED THIRUVANANTHAPURAM\t\t\n");
                    printf("\t\t\t________________________________\t\t\t\t\n\n");
                    printf("\n\t\t\t\t\tHOW MANY TICKETS WANT YOU\t=~>\t");
                    scanf("%d", &qty);
                    prize = 500 * qty;
                    total += prize;
                    printf("\n\t\t\t TOTAL AMOUNT IS =~> \t $ %d\t\t\n", total);
                    printf("\t\t1.PAY THE AMOUNT\n\t\t 0.BACKPAGE&CONTINUE \n\t\t 3.GOTO MAIN MENU\t=");
                    scanf("%d",&back);
                    while(back==3)
                    goto MAIN;
                    if(back==0)
                    goto GO;
                    if(back==1)
                    {printf("\t\t\t_____________________________________\t\t\n");
                    printf("\t\t\tTHANK YOU FOR BOOKING SPEEDER SERAN\n\n\t\t\t\tENJOY YOUR JOURNEY\t\t\n");
                    printf("\t\t\t_____________________________________\t\t\n");}
                    else
                    {
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    printf("\n\n\t\t\t\t!!!!!!!!~YOUR ENTERED INVAILD OPTION PLEASE CHECK IT~!!!!!!!!\t\t\t\t\n");
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    }
                    break;
                }
                case 3: {
                    printf("\n\t\t\tYOUR SELECTED WEST HILLS\t\t\n");
                    printf("\t\t\t________________________________\t\t\t\t\n\n");
                    printf("\n\t\t\t\t\tHOW MANY TICKETS WANT YOU\t=~>\t");
                    scanf("%d", &qty);
                    prize = 420 * qty;
                    total += prize;
                    printf("\n\t\t\t TOTAL AMOUNT IS =~> \t $ %d\t\t\n", total);
                    printf("\t\t 1.PAY THE AMOUNT\n\t\t 0.BACKPAGE&CONTINUE \n\t\t 3.GOTO MAIN MENU\t=");
                    scanf("%d",&back);
                    while(back==3)
                    goto MAIN;
                    if(back==0)
                    goto GO;
                    if(back==1)
                    {printf("\t\t\t_____________________________________\t\t\n");
                    printf("\t\t\tTHANK YOU FOR BOOKING SPEEDER SERAN\n\n\t\t\t\tENJOY YOUR JOURNEY\t\t\n");
                    printf("\t\t\t_____________________________________\t\t\n");}
                    else
                    {
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    printf("\n\n\t\t\t\t!!!!!!!!~YOUR ENTERED INVAILD OPTION PLEASE CHECK IT~!!!!!!!!\t\t\t\t\n");
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    }
                    break;
                }
                }

            }
            }

        }
        }

   break; }
                case 3:
                    {
        int ac, sleeper, to;
        CO:
        printf("\n\t\t\t\tTHANK YOU FOR SELECTING PANDIAN PANTHERS\t\t\t\t\t\t\n");
        printf("\t\t\t\t*****************************************\t\t\t\t\n\n");
        printf("\n\t\t\t\t\tSELECT YOUR BUS TYPE\t\t\n");
        printf("\t\t\t\t\t____________________\t\t\n\n");
        printf("\t\t 1.AC \n \t\t 2.NON AC\t\t");
        scanf("%d", &ac);

        switch (ac) {
        case 1: {
            printf("\n\t\t\tSELECT YOUR COMFORTABLE TRAVEL MODE\t\t\t\n");
            printf("\t\t\t_____________________________________\t\t\t\t\n\n");
            printf("\t\t 1.SLEEPER SEAT \n\t\t 2.NORMAL SEAT\t\t");
            scanf("%d", &sleeper);

            switch (sleeper) {
            case 1: {
                printf("\n\t\t\t YOUR SELECTED IT SLEEPER MODE SEAT\t\t\n");
                printf("\t\t\t....................................\t\t\n\n");
                printf("\t\t\t\tWHERE ARE YOU GOING NOW\n");
                printf("\t\t\t\t^______________________^\t\t\t\t\n\n");
                printf("\t\t\t 1.MADURAI \n\t\t\t2.AVANIYAPURAM \n\t\t\t3.THIRUPARANKUNDRAM\t\t");
                scanf("%d", &to);


                switch (to) {
                case 1: {
                    printf("\n\t\t\tYOUR SELECTED PLACE IS MADURAI\t\t\t\t\n");
                    printf("\t\t\t________________________________\t\t\t\t\n\n");
                    printf("\n\t\t\t\t\tHOW MANY TICKETS WANT YOU\t=~>\t");
                    scanf("%d", &qty);
                    prize = 600 * qty;
                    total += prize;
                    printf("\n\t\t\t TOTAL AMOUNT IS =~> \t $ %d\t\t\n", total);
                    printf("\t\t 1.PAY THE AMOUNT\n\t\t 0.BACKPAGE&CONTINUE \n\t\t 3.GOTO MAIN MENU\t\t=\t");
                    scanf("%d",&back);
                    while(back==3)
                    goto MAIN;
                    if(back==0)
                    goto CO;
                    if(back==1)
                    {printf("\t\t\t_____________________________________\t\t\n");
                    printf("\t\t\tTHANK YOU FOR BOOKING PANDIAN PANTHERS\n\n\t\t\t\tENJOY YOUR JOURNEY\n");
                    printf("\t\t\t_____________________________________\t\t\n");}
                    else
                    {
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    printf("\n\n\t\t\t\t!!!!!!!!~YOUR ENTERED INVAILD OPTION PLEASE CHECK IT~!!!!!!!!\t\t\t\t\n");
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    }
                    break;
                }
                case 2: {
                    printf("\n\t\t\tYOUR SELECTED PLACE IS AVANIYAPURAM\t\t\t\n");
                    printf("\t\t\t___________________________________\t\t\t\t\n\n");
                    printf("\n\t\t\t\t\tHOW MANY TICKETS WANT YOU\t=~>\t");
                    scanf("%d", &qty);
                    prize = 550 * qty;
                    total += prize;
                    printf("\n\t\t\t TOTAL AMOUNT IS =~> \t $ %d\t\t\n", total);
                    printf("\t\t 1.PAY THE AMOUNT\n\t\t 0.BACKPAGE&CONTINUE \n\t\t 3.GOTO MAIN MENU\t=");
                    scanf("%d",&back);
                    while(back==3)
                    goto MAIN;
                    if(back==0)
                    goto CO;
                    if(back==1)
                    {printf("\t\t\t_____________________________________\t\t\n");
                    printf("\t\t\tTHANK YOU FOR BOOKING PANDIAN PANTHERS \n\n\t\t\t\tENJOY YOUR JOURNEY\t\t\n");
                    printf("\t\t\t_____________________________________\t\t\n");}
                    else
                    {
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    printf("\n\n\t\t\t\t!!!!!!!!~YOUR ENTERED INVAILD OPTION PLEASE CHECK IT~!!!!!!!!\t\t\t\t\n");
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    }
                    break;
                }
                case 3: {
                    printf("\n\t\t\tYOUR SELECTED PLACE IS THIRUPARANKUNDRAM\t\t\t\n");
                    printf("\t\t\t________________________________\t\t\t\t\n\n");
                    printf("\n\t\t\t\t\tHOW MANY TICKETS WANT YOU\t=~>\t");
                    scanf("%d", &qty);
                    prize = 1100 * qty;
                    total += prize;
                    printf("\n\t\t\t TOTAL AMOUNT IS =~> \t $ %d\t\t\n", total);
                    printf("\t\t 1.PAY THE AMOUNT\n\t\t 0.BACKPAGE&CONTINUE \n\t\t 3.GOTO MAIN MENU\t=");
                    scanf("%d",&back);
                    while(back==3)
                    goto MAIN;
                    if(back==0)
                    goto CO;
                    if(back==1)
                    {printf("\t\t\t_____________________________________\t\t\n");
                    printf("\t\t\tTHANK YOU FOR BOOKING PANDIAN PANTHERS\n\n\t\t\t\tENJOY YOUR JOURNEY\t\t\n");
                    printf("\t\t\t_____________________________________\t\t\n");}
                    else
                    {
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    printf("\n\n\t\t\t\t!!!!!!!!~YOUR ENTERED INVAILD OPTION PLEASE CHECK IT~!!!!!!!!\t\t\t\t\n");
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    }
                    break;
                }
                }
                break;
            }
            case 2: {
                int no;
                printf("\t\t\tYOUR SELECTED NORMAL MODE SEAT\t\t\n");
                printf("\t\t\t_____________________________________\t\t\t\t\n\n");
                printf("\t\t\tWHERE ARE YOU GOING\t\t\n");
                printf("\t\t\t 1.MADURAI \n\t\t\t2.AVANIYAPURAM \n\t\t\t3.THIRUPARANKUNDRAM\t\t");
                scanf("%d", &no);

                switch (no) {
                case 1: {
                    printf("\n\t\t\tYOUR SELECTED MADURAI\t\t\n");
                    printf("\t\t\t________________________________\t\t\t\t\n\n");
                    printf("\n\t\t\t\t\tHOW MANY TICKETS WANT YOU\t=~>\t");
                    scanf("%d", &qty);
                    prize = 310 * qty;
                    total += prize;
                    printf("\n\t\t\t TOTAL AMOUNT IS =~> \t $ %d\t\t\n", total);
                    printf("\t\t 1.PAY THE AMOUNT\n\t\t 0.BACKPAGE&CONTINUE \n\t\t 3.GOTO MAIN MENU\t=");
                    scanf("%d",&back);
                    while(back==3)
                    goto MAIN;
                    if(back==0)
                    goto CO;
                    if(back==1)
                    {printf("\t\t\t_____________________________________\t\t\n");
                    printf("\t\t\tTHANK YOU FOR BOOKING PANDIAN PANTHERS\n\n\t\t\t\tENJOY YOUR JOURNEY\t\t\n");
                    printf("\t\t\t_____________________________________\t\t\n");}
                    else
                    {
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    printf("\n\n\t\t\t\t!!!!!!!!~YOUR ENTERED INVAILD OPTION PLEASE CHECK IT~!!!!!!!!\t\t\t\t\n");
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    }
                    break;
                }
                case 2: {
                    printf("\n\t\t\tYOUR SELECTED AVANIYAPURAM\t\t\t");
                    printf("\t\t\t________________________________\t\t\t\t\n\n");
                    printf("\n\t\t\t\t\tHOW MANY TICKETS WANT YOU\t=~>\t");
                    scanf("%d", &qty);
                    prize = 345 * qty;
                    total += prize;
                    printf("\n\t\t\t TOTAL AMOUNT IS =~> \t $ %d\t\t\n", total);
                    printf("\t\t 1.PAY THE AMOUNT\n\t\t 0.BACKPAGE&CONTINUE \n\t\t 3.GOTO MAIN MENU\t=");
                    scanf("%d",&back);
                    while(back==3)
                    goto MAIN;
                    if(back==0)
                    goto CO;
                    if(back==1)
                    {printf("\t\t\t_____________________________________\t\t\n");
                    printf("\t\t\tTHANK YOU FOR BOOKING PANDIAN PANTHERS\n\n\t\t\t\tENJOY YOUR JOURNEY\t\t\n");
                    printf("\t\t\t_____________________________________\t\t\n");}
                    else
                    {
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    printf("\n\n\t\t\t\t!!!!!!!!~YOUR ENTERED INVAILD OPTION PLEASE CHECK IT~!!!!!!!!\t\t\t\t\n");
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    }
                    break;
                }
                case 3: {
                    printf("\n\t\t\tYOUR SELECTED THIRUPARANKUNDRAM\t\t\t\n");
                    printf("\t\t\t________________________________\t\t\t\t\n\n");
                    printf("\n\t\t\t\t\tHOW MANY TICKETS WANT YOU\t=~>\t");
                    scanf("%d", &qty);
                    prize = 500 * qty;
                    total += prize;
                    printf("\n\t\t\t TOTAL AMOUNT IS =~> \t $ %d\t\t\n", total);
                    printf("\t\t 1.PAY THE AMOUNT\n\t\t 0.BACKPAGE&CONTINUE \n\t\t 3.GOTO MAIN MENU\t=");
                    scanf("%d",&back);
                    while(back==3)
                    goto MAIN;
                    if(back==0)
                    goto CO;
                    if(back==1)
                    {printf("\t\t\t_____________________________________\t\t\n");
                    printf("\t\t\tTHANK YOU FOR BOOKING PANDIAN PANTHERS\n\n\t\t\t\tENJOY YOUR JOURNEY\t\t\n");
                    printf("\t\t\t_____________________________________\t\t\n");}
                    else
                    {
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    printf("\n\n\t\t\t\t!!!!!!!!~YOUR ENTERED INVAILD OPTION PLEASE CHECK IT~!!!!!!!!\t\t\t\t\n");
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    }
                    break;
                }
                }
                break;
            }
            }
            break;
        }
        case 2: {
            int nonac;

            printf("\t\t\tYOUR SELECTED NON-AC BUS\t\t\n");
            printf("\t\t\t________________________________\t\t\t\t\n\n");
            printf("\t\t\tSELECT YOUR BUS TYPE\t\t\n\n");
            printf("\t\t\t 1.NORMAL BUS\n\t\t\t 2.EXPRESS BUS\t\t");
            scanf("%d", &nonac);

            switch (nonac) {
            case 1: {
                int fm;
                printf("\n\t\t\tYOUR SELECTED NORMAL TYPE BUS\t\t\n");
                printf("\t\t\t________________________________\t\t\t\t\n\n");
                printf("\t\t\tWHERE ARE YOU GOING TO\t\t\n\n");
                printf("\t\t\t 1.MADURAI \n\t\t\t2.AVANIYAPURAM \n\t\t\t3.THIRUPARANKUNDRAM\t\t");
                scanf("%d", &fm);

                switch (fm) {
                case 1: {
                    printf("\n\t\t\tYOUR SELECTED MADURAI\t\t\n");
                    printf("\t\t\t________________________________\t\t\t\t\n\n");
                    printf("\n\t\t\t\t\tHOW MANY TICKETS WANT YOU\t=~>\t");
                    scanf("%d", &qty);
                    prize = 220*qty;
                    total += prize;
                    printf("\n\t\t\t TOTAL AMOUNT IS =~> \t $ %d\t\t\n", total);
                    printf("\t\t 1.PAY THE AMOUNT\n\t\t 0.BACKPAGECONTINUE \n\t\t 3.GOTO MAIN MENU\t=");
                    scanf("%d",&back);
                    while(back==3)
                    goto MAIN;
                    if(back==0)
                    goto CO;
                    if(back==1)
                    {printf("\t\t\t_____________________________________\t\t\n");
                    printf("\t\t\tTHANK YOU FOR BOOKING PANDIAN PANTHERS\n\n\t\t\t\tENJOY YOUR JOURNEY\t\t\n");
                    printf("\t\t\t_____________________________________\t\t\n");}
                    else
                    {
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    printf("\n\n\t\t\t\t!!!!!!!!~YOUR ENTERED INVAILD OPTION PLEASE CHECK IT~!!!!!!!!\t\t\t\t\n");
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    }
                    break;
                }
                case 2: {
                    printf("\n\t\t\tYOUR SELECTED AVANIYAPURAM\t\t\n");
                    printf("\t\t\t________________________________\t\t\t\t\n\n");
                    printf("\n\t\t\t\t\tHOW MANY TICKETS WANT YOU\t=~>\t");
                    scanf("%d", &qty);
                    prize = 240 * qty;
                    total += prize;
                    printf("\n\t\t\t TOTAL AMOUNT IS =~> \t $ %d\t\t\n", total);
                    printf("\t\t 1.PAY THE AMOUNT\n\t\t 0.BACKPAGE&CONTINUE \n\t\t 3.GOTO MAIN MENU\t=");
                    scanf("%d",&back);
                    while(back==3)
                    goto MAIN;
                    if(back==0)
                    goto CO;
                    if(back==1)
                    {printf("\t\t\t_____________________________________\t\t\n");
                    printf("\t\t\tTHANK YOU FOR BOOKING PANDIAN PANTHERS\n\n\t\t\t\tENJOY YOUR JOURNEY\t\t\n");
                    printf("\t\t\t_____________________________________\t\t\n");}
                    else
                    {
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    printf("\n\n\t\t\t\t!!!!!!!!~YOUR ENTERED INVAILD OPTION PLEASE CHECK IT~!!!!!!!!\t\t\t\t\n");
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    }
                    break;
                }
                case 3: {
                    printf("\n\t\t\tYOUR SELECTED THIRUPARANKUNDRAM\t\t\n");
                    printf("\t\t\t________________________________\t\t\t\t\n\n");
                    printf("\n\t\t\t\t\tHOW MANY TICKETS WANT YOU\t=~>\t");
                    scanf("%d", &qty);
                    prize = 320 * qty;
                    total += prize;
                    printf("\n\t\t\t TOTAL AMOUNT IS =~> \t $ %d\t\t\n", total);
                    printf("\t\t 1.PAY THE AMOUNT\n\t\t 0.BACKPAGE&CONTINUE \n\t\t 3.GOTO MAIN MENU\t=");
                    scanf("%d",&back);
                    while(back==3)
                    goto MAIN;
                    if(back==0)
                    goto CO;
                    if(back==1)
                    {printf("\t\t\t_____________________________________\t\t\n");
                    printf("\t\t\tTHANK YOU FOR BOOKING PANDIAN PANTHERS\n\n\t\t\t\tENJOY YOUR JOURNEY\t\t\n");
                    printf("\t\t\t_____________________________________\t\t\n");}
                    else
                    {
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    printf("\n\n\t\t\t\t!!!!!!!!~YOUR ENTERED INVAILD OPTION PLEASE CHECK IT~!!!!!!!!\t\t\t\t\n");
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    }
                    break;
                }
                }
                break;
            }
            case 2: {
                int k;
                printf("\n\t\t\tYOUR SELECTED EXPRESS BUS\t\t\n");
                printf("\t\t\t________________________________\t\t\t\t\n\n");
                printf("\t\t\tWHERE ARE YOU GOING TO\t\t\n\n");
                printf("\t\t\t 1.MADURAI \n\t\t\t2.AVANIYAPURAM \n\t\t\t3.THIRUPARANKUNDRAM\t\t");
                scanf("%d", &k);

                switch (k) {
                case 1: {
                    printf("\n\t\t\tYOUR SELECTED MADURAI\t\t\n");
                    printf("\t\t\t________________________________\t\t\t\t\n\n");
                    printf("\n\t\t\t\t\tHOW MANY TICKETS WANT YOU\t=~>\t");
                    scanf("%d", &qty);
                    prize = 220*qty;
                    total += prize;
                    printf("\n\t\t\t TOTAL AMOUNT IS =~> \t $ %d\t\t\n", total);
                    printf("\t\t 1.PAY THE AMOUNT\n\t\t 0.BACKPAGE \n\t\t 3.GOTO MAIN MENU\t=");
                    scanf("%d",&back);
                    while(back==3)
                    goto MAIN;
                    if(back==0)
                    goto CO;
                    if(back==1)
                    {printf("\t\t\t_____________________________________\t\t\n");
                    printf("\t\t\tTHANK YOU FOR BOOKING PANDIAN PANTHERS\n\n\t\t\t\tENJOY YOUR JOURNEY\t\t\n");
                    printf("\t\t\t_____________________________________\t\t\n");}
                    else
                    {
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    printf("\n\n\t\t\t\t!!!!!!!!~YOUR ENTERED INVAILD OPTION PLEASE CHECK IT~!!!!!!!!\t\t\t\t\n");
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    }
                    break;
                }
                case 2: {
                    printf("\n\t\t\tYOUR SELECTED AVANIYAPURAM\t\t\n");
                    printf("\t\t\t________________________________\t\t\t\t\n\n");
                    printf("\n\t\t\t\t\tHOW MANY TICKETS WANT YOU\t=~>\t");
                    scanf("%d", &qty);
                    prize = 290 * qty;
                    total += prize;
                    printf("\n\t\t\t TOTAL AMOUNT IS =~> \t $ %d\t\t\n", total);
                    printf("\t\t1.PAY THE AMOUNT\n\t\t 0.BACKPAGE&CONTINUE \n\t\t 3.GOTO MAIN MENU\t=");
                    scanf("%d",&back);
                    while(back==3)
                    goto MAIN;
                    if(back==0)
                    goto CO;
                    if(back==1)
                    {printf("\t\t\t_____________________________________\t\t\n");
                    printf("\t\t\tTHANK YOU FOR BOOKING PANDIAN PANTHERS\n\n\t\t\t\tENJOY YOUR JOURNEY\t\t\n");
                    printf("\t\t\t_____________________________________\t\t\n");}
                    else
                    {
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    printf("\n\n\t\t\t\t!!!!!!!!~YOUR ENTERED INVAILD OPTION PLEASE CHECK IT~!!!!!!!!\t\t\t\t\n");
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    }
                    break;
                }
                case 3: {
                    printf("\n\t\t\tYOUR SELECTED THIRUPARANKUNDRAM\t\t\n");
                    printf("\t\t\t________________________________\t\t\t\t\n\n");
                    printf("\n\t\t\t\t\tHOW MANY TICKETS WANT YOU\t=~>\t");
                    scanf("%d", &qty);
                    prize = 450 * qty;
                    total += prize;
                    printf("\n\t\t\t TOTAL AMOUNT IS =~> \t $ %d\t\t\n", total);
                    printf("\t\t 1.PAY THE AMOUNT\n\t\t 0.BACKPAGE&CONTINUE \n\t\t 3.GOTO MAIN MENU\t=");
                    scanf("%d",&back);
                    while(back==3)
                    goto MAIN;
                    if(back==0)
                    goto CO;
                    if(back==1)
                    {printf("\t\t\t_____________________________________\t\t\n");
                    printf("\t\t\tTHANK YOU FOR BOOKING PANDIAN PANTHERS\n\n\t\t\t\tENJOY YOUR JOURNEY\t\t\n");
                    printf("\t\t\t_____________________________________\t\t\n");}
                    else
                    {
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    printf("\n\n\t\t\t\t!!!!!!!!~YOUR ENTERED INVAILD OPTION PLEASE CHECK IT~!!!!!!!!\t\t\t\t\n");
                    printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
                    }
                    break;
                }
                }

            }
            }

        }
        }
break;
    }{
        default:
        printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
        printf("\n\n\t\t\t\t!!!!!!!!~YOUR ENTERED INVAILD OPTION PLEASE CHECK IT~!!!!!!!!\t\t\t\t\n");
        printf("\t\t\t\t____________________________________________________________\t\t\t\t\t\t\t");
        break;

    }

        }








    return 0;
}
